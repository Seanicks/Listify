import React, { useState, useEffect } from "react";
import axios from "axios";
import './App.css';  

const App = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [students, setStudents] = useState([]);
  const [editingStudentId, setEditingStudentId] = useState(null);

  const apiUrl = "http://localhost:8080/api/student";

  
  const fetchStudents = async () => {
    try {
      const response = await axios.get(`${apiUrl}/getAllStudent`);
      setStudents(response.data);
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  
  const saveStudent = async (e) => {
    e.preventDefault();
    try {
      const student = { firstName, lastName };
      if (editingStudentId) {
        
        await axios.put(`${apiUrl}/putStudentDetails`, student, {
          params: { id: editingStudentId }  
        });
        setEditingStudentId(null);
      } else {
      
        await axios.post(`${apiUrl}/postStudentRecord`, student);
      }
      setFirstName("");
      setLastName("");
      fetchStudents();  
    } catch (error) {
      console.error("Error saving student:", error);
    }
  };

  
  const deleteStudent = async (id) => {
    try {
      await axios.delete(`${apiUrl}/deleteStudent/${id}`);
      fetchStudents();  
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

 
  const editStudent = (student) => {
    setFirstName(student.firstName);
    setLastName(student.lastName);
    setEditingStudentId(student.id);  
  };

  return (
    <div className="app-container">
      <h1 className="title">Student</h1>
      <form onSubmit={saveStudent} className="form-container">
        <div className="input-group">
          <label>First Name: </label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
            className="input-field"
          />
        </div>
        <div className="input-group">
          <label>Last Name: </label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
            className="input-field"
          />
        </div>
        <button type="submit" className="save-btn">
          {editingStudentId ? "Update Student" : "Add Student"}
        </button>
      </form>

      <h2 className="student-list-title">Student List</h2>
      <ul className="student-list">
        {students.map((student) => (
          <li key={student.id} className="student-item">
            {student.firstName} {student.lastName}
            <div className="action-buttons">
              <button className="edit-btn" onClick={() => editStudent(student)}>Edit</button>
              <button className="delete-btn" onClick={() => deleteStudent(student.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
