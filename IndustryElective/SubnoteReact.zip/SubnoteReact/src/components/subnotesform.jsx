import React, { useState } from 'react'; 
import { createSubnote } from '../subnoteservice';

const SubnoteForm = ({ fetchSubnotes }) => {
    const [subnote, setSubnote] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        await createSubnote({ subnote });
        setSubnote('');
        fetchSubnotes();
    };

    return (
        <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '20px' }}>
            <input
                type="text"
                value={subnote}
                onChange={(e) => setSubnote(e.target.value)}
                placeholder="Add notes to the list"
                style={{
                    padding: '10px',
                    borderRadius: '20px',
                    border: '1px solid #ccc',
                    marginRight: '10px',
                    width: '350px',  // Increased width for better visibility
                    outline: 'none',
                    fontSize: '16px'  // Added font size for clarity
                }}
            />
            <button
                type="submit"
                style={{
                    backgroundColor: 'blue',
                    color: 'white',
                    padding: '10px 25px',  // Increased padding for button
                    borderRadius: '20px',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '16px'  // Added font size for consistency
                }}
            >
                Add Subnote
            </button>
        </form>
    );
};

export default SubnoteForm;