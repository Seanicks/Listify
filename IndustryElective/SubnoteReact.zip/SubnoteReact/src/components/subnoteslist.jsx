import React, { useEffect, useState } from 'react';
import { getAllSubnotes, updateSubnote, deleteSubnote } from '../subnoteservice';

const SubnotesList = () => {
    const [subnotes, setSubnotes] = useState([]);
    const [editing, setEditing] = useState(null);
    const [newText, setNewText] = useState('');

    useEffect(() => {
        fetchSubnotes();
    }, []);

    const fetchSubnotes = async () => {
        const data = await getAllSubnotes();
        setSubnotes(data);
    };

    const handleUpdate = async (id) => {
        await updateSubnote(id, { subnote: newText });
        setEditing(null);
        fetchSubnotes();
    };

    const handleDelete = async (id) => {
        await deleteSubnote(id);
        fetchSubnotes();
    };

    return (
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <h1 style={{ fontWeight: 'bold', marginBottom: '20px' }}>Subnotes List</h1>
            <table style={{ width: '60%', margin: '0 auto', borderCollapse: 'collapse' }}>
                <thead>
                    <tr style={{ backgroundColor: '#f2f2f2' }}>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>#</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Subnote</th>
                        <th style={{ padding: '10px', border: '1px solid #ccc' }}>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {subnotes.map((subnote, index) => (
                        <tr key={subnote.subnoteID} style={{ borderBottom: '1px solid #ccc' }}>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>{index + 1}</td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                                {editing === subnote.subnoteID ? (
                                    <input
                                        type="text"
                                        value={newText}
                                        onChange={(e) => setNewText(e.target.value)}
                                        style={{ width: '100%', padding: '5px', borderRadius: '5px', marginRight: '10px' }}
                                    />
                                ) : (
                                    subnote.subnote
                                )}
                            </td>
                            <td style={{ padding: '10px', border: '1px solid #ccc' }}>
                                {editing === subnote.subnoteID ? (
                                    <button
                                        onClick={() => handleUpdate(subnote.subnoteID)}
                                        style={{ marginRight: '10px', backgroundColor: 'blue', color: 'white', borderRadius: '20px', padding: '5px 10px', cursor: 'pointer' }}
                                    >
                                        Update
                                    </button>
                                ) : (
                                    <button
                                        onClick={() => {
                                            setEditing(subnote.subnoteID);
                                            setNewText(subnote.subnote);
                                        }}
                                        style={{ marginRight: '10px', backgroundColor: 'blue', color: 'white', borderRadius: '20px', padding: '5px 10px', cursor: 'pointer' }}
                                    >
                                        Update
                                    </button>
                                )}
                                <button
                                    onClick={() => handleDelete(subnote.subnoteID)}
                                    style={{ backgroundColor: 'red', color: 'white', borderRadius: '20px', padding: '5px 10px', cursor: 'pointer' }}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default SubnotesList;