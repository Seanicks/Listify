import axios from 'axios';

const BASE_URL = '/api/subnotes';

export const getAllSubnotes = async () => {
    const response = await axios.get(BASE_URL);
    return response.data;
};

export const createSubnote = async (subnote) => {
    const response = await axios.post(BASE_URL, subnote);
    return response.data;
};

export const updateSubnote = async (id, subnote) => {
    const response = await axios.put(`${BASE_URL}/${id}`, subnote);
    return response.data;
};

export const deleteSubnote = async (id) => {
    const response = await axios.delete(`${BASE_URL}/${id}`);
    return response.data;
};
