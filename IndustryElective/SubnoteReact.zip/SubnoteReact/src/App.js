// src/App.js

import React from 'react';
import SubnotesList from './components/subnoteslist';
import SubnoteForm from './components/subnotesform';

const App = () => {
    return (
        <div>
            <h1>Subnotes Application</h1>
            <SubnoteForm />
            <SubnotesList />
        </div>
    );
};

export default App;
