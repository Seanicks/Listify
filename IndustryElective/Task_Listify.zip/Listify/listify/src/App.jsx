import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';

function App() {
    const [todos, setTodos] = useState([]);
    const [todoValue, setTodoValue] = useState('');
    const [editId, setEditId] = useState(null);
    const [taskStatus, setTaskStatus] = useState('Pending');
    const apiUrl = 'http://localhost:8080/api/task';

    // Fetch all todos from backend
    const fetchTodos = async () => {
        try {
            const response = await axios.get(`${apiUrl}/getAllTasks`);
            setTodos(response.data);
        } catch (error) {
            console.error("Error fetching tasks:", error);
        }
    };

    // Add new todo or update existing todo
    const handleAddTodos = async () => {
        if (!todoValue) {
            alert("Please enter a task");
            return;
        }

        try {
            if (editId) {
                // Update the existing task
                await handleUpdate(editId, {
                    task: todoValue,
                    taskStatus: taskStatus,
                });
            } else {
                // Add new task
                const response = await axios.post(`${apiUrl}/posttask`, {
                    task: todoValue,
                    taskStatus: taskStatus
                });
                setTodos((prevTodos) => [...prevTodos, response.data]);
            }
            // Clear the input fields after action
            setTodoValue('');
            setTaskStatus('Pending');
            setEditId(null); // Reset edit mode
        } catch (error) {
            console.error("Error adding/updating task:", error);
        }
    };

    // Update function
    const handleUpdate = async (id, updatedTask) => {
        try {
            const response = await axios.put(`${apiUrl}/putTaskDetails/${id}`, updatedTask);
            setTodos((prevTodos) =>
                prevTodos.map((todo) => (todo.id === id ? response.data : todo))
            );
            setEditId(null);
        } catch (error) {
            console.error("Error updating task:", error);
        }
    };

    // Delete todo
    const handleDeleteTodo = async (id) => {
        try {
            await axios.delete(`${apiUrl}/deleteTask/${id}`);
            setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
        } catch (error) {
            console.error("Error deleting task:", error);
        }
    };

    // Set the current todo for editing
    const handleEditTodo = (id) => {
        const todoToEdit = todos.find((todo) => todo.id === id);
        setTodoValue(todoToEdit.task);
        setTaskStatus(todoToEdit.taskStatus);
        setEditId(id);
    };

    // Fetch todos on component mount
    useEffect(() => {
        fetchTodos();
    }, []);

    return (
        <div className="container">
            {/* Sidebar */}
            <div className="sidebar">
                <h2>LISTIFY</h2>
                <ul>
                    <li>CALENDAR</li>
                    <li>TASKS</li>
                    <li className="settings">SETTINGS</li> {/* Settings moved to the bottom */}
                </ul>
            </div>

            {/* Main Content */}
            <div className="main-content">
                <div className="task-header">
                    <h1>TASKS</h1>
                    <div className="user-profile">
                        <img src="path-to-profile-pic" alt="Profile" />
                        <span>John Doe</span>
                    </div>
                </div>

                <div className="divider"></div> {/* Divider line */}

                {/* Task List */}
                <div className="tasks-list">
                    {todos.map((todo) => (
                        <div className="task-item" key={todo.id}>
                            <h3>{todo.task}</h3>
                            <p>Status: {todo.taskStatus}</p>
                            <div className="task-actions">
                                <button className="update-btn" onClick={() => handleEditTodo(todo.id)}>
                                    Update
                                </button>
                                <button className="delete-btn" onClick={() => handleDeleteTodo(todo.id)}>
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Task Input at the Bottom */}
                <div className="todo-input">
                    <input
                        type="text"
                        value={todoValue}
                        onChange={(e) => setTodoValue(e.target.value)}
                        placeholder="Enter a task"
                    />
                    <select
                        value={taskStatus}
                        onChange={(e) => setTaskStatus(e.target.value)}
                    >
                        <option value="Pending">Pending</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Done">Done</option>
                    </select>
                    <button onClick={handleAddTodos}>
                        {editId ? 'Update Task' : 'Add Task'}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default App;
