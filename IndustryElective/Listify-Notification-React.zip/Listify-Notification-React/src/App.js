import React from 'react';
import NotificationComponent from './NotificationComponent';

const App = () => {
    return (
        <div>
            <h1>Notification Management</h1>
            <NotificationComponent />
        </div>
    );
};

export default App;
