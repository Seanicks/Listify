import axios from 'axios';

const API_URL = 'http://localhost:8080/api/notifications';

// Get all notifications
export const getAllNotifications = async () => {
    try {
        const response = await axios.get(API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching notifications:', error);
        throw error;
    }
};

// Create a new notification
export const createNotification = async (notification) => {
    try {
        const response = await axios.post(API_URL, notification, {
            headers: {
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error creating notification:', error);
        throw error;
    }
};

// Update an existing notification by ID
export const updateNotification = async (id, notification) => {
    try {
        const response = await axios.put(`${API_URL}/${id}`, notification, {
            headers: {
                'Content-Type': 'application/json',
            },
        });
        return response.data;
    } catch (error) {
        console.error('Error updating notification:', error);
        throw error;
    }
};

// Delete a notification by ID
export const deleteNotification = async (id) => {
    try {
        await axios.delete(`${API_URL}/${id}`);
    } catch (error) {
        console.error('Error deleting notification:', error);
        throw error;
    }
};
