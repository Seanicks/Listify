import React, { useEffect, useState } from 'react';
import {
    createNotification,
    updateNotification,
    getAllNotifications,
    deleteNotification,
} from './notificationService';

const NotificationComponent = () => {
    const [notifications, setNotifications] = useState([]);
    const [taskStatus, setTaskStatus] = useState('');
    const [date, setDate] = useState('');
    const [editId, setEditId] = useState(null);

    // Fetch all notifications on component mount
    useEffect(() => {
        const fetchNotifications = async () => {
            try {
                const data = await getAllNotifications();
                setNotifications(data);
            } catch (error) {
                console.error("Failed to fetch notifications", error);
            }
        };
        fetchNotifications();
    }, []);

    // Handle creating or updating a notification
    const handleSubmit = async (e) => {
        e.preventDefault();
        const notification = { taskStatus, date };

        try {
            if (editId) {
                await updateNotification(editId, notification);
            } else {
                await createNotification(notification);
            }

            // Reset fields and fetch updated notifications
            setTaskStatus('');
            setDate('');
            setEditId(null);
            const data = await getAllNotifications();
            setNotifications(data);
        } catch (error) {
            console.error("Failed to submit notification", error);
        }
    };

    // Handle edit
    const handleEdit = (notification) => {
        setTaskStatus(notification.taskStatus);
        setDate(notification.date);
        setEditId(notification.notifiID); // Use your ID field
    };

    // Handle delete
    const handleDelete = async (id) => {
        try {
            await deleteNotification(id);
            const data = await getAllNotifications();
            setNotifications(data);
        } catch (error) {
            console.error("Failed to delete notification", error);
        }
    };

    return (
        <div>
            <h2>Notifications</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Task Status"
                    value={taskStatus}
                    onChange={(e) => setTaskStatus(e.target.value)}
                    required
                />
                <input
                    type="datetime-local"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    required
                />
                <button type="submit">{editId ? 'Update' : 'Create'} Notification</button>
            </form>

            <ul>
                {notifications.map((notification) => (
                    <li key={notification.notifiID}>
                        {notification.taskStatus} - {notification.date}
                        <button onClick={() => handleEdit(notification)}>Edit</button>
                        <button onClick={() => handleDelete(notification.notifiID)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default NotificationComponent;
