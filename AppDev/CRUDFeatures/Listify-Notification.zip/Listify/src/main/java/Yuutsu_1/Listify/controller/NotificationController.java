package Yuutsu_1.Listify.controller;

import Yuutsu_1.Listify.entity.NotificationEntity;
import Yuutsu_1.Listify.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "http://localhost:3000") // Enable CORS for this controller
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    // Create a new Notification
    @PostMapping
    public ResponseEntity<NotificationEntity> createNotification(@RequestBody NotificationEntity notification) {
        NotificationEntity savedNotification = notificationService.saveNotification(notification);
        return ResponseEntity.status(201).body(savedNotification); // Return 201 Created status
    }

    // Update an existing Notification
    @PutMapping("/{id}")
    public ResponseEntity<NotificationEntity> updateNotification(@PathVariable("id") Long notifiID,
                                                                  @RequestBody NotificationEntity notification) {
        Optional<NotificationEntity> updatedNotification = notificationService.updateNotification(notifiID, notification);
        return updatedNotification.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all notifications
    @GetMapping
    public List<NotificationEntity> getAllNotifications() {
        return notificationService.getAllNotifications();
    }

    // Get a notification by ID
    @GetMapping("/{id}")
    public ResponseEntity<NotificationEntity> getNotificationById(@PathVariable("id") Long notifiID) {
        Optional<NotificationEntity> notification = notificationService.getNotificationById(notifiID);
        return notification.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete a notification by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNotification(@PathVariable("id") Long notifiID) {
        notificationService.deleteNotification(notifiID);
        return ResponseEntity.noContent().build();
    }
}
