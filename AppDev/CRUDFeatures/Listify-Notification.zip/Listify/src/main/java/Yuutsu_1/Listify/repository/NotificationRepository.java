package Yuutsu_1.Listify.repository;

import Yuutsu_1.Listify.entity.NotificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRepository extends JpaRepository<NotificationEntity, Long> {
    // No need to add methods here unless you need custom queries
}
