package Yuutsu_1.Listify.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
public class NotificationEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notifiID;
    
    private String taskStatus;
    
    private LocalDateTime date;
    
    private String message;
    
    private String recipient;
    
    private Boolean isRead;

    // Constructors, getters, setters
    public NotificationEntity() {}

    public NotificationEntity(String taskStatus, LocalDateTime date, String message, String recipient, Boolean isRead) {
        this.taskStatus = taskStatus;
        this.date = date;
        this.message = message;
        this.recipient = recipient;
        this.isRead = isRead;
    }

    public Long getNotifiID() {
        return notifiID;
    }

    public void setNotifiID(Long notifiID) {
        this.notifiID = notifiID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }
}
