package Yuutsu_1.Listify.service;

import Yuutsu_1.Listify.entity.NotificationEntity;
import Yuutsu_1.Listify.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // Create or Update Notification
    public NotificationEntity saveNotification(NotificationEntity notification) {
        return notificationRepository.save(notification);
    }
    
    public Optional<NotificationEntity> updateNotification(Long notifiID, NotificationEntity notification) {
        // Check if the notification exists
        Optional<NotificationEntity> existingNotification = notificationRepository.findById(notifiID);
        
        if (existingNotification.isPresent()) {
            // Update the existing notification with new values
            NotificationEntity updatedNotification = existingNotification.get();
            updatedNotification.setTaskStatus(notification.getTaskStatus());
            updatedNotification.setDate(notification.getDate());
            // Set other fields as necessary

            // Save the updated notification back to the repository
            notificationRepository.save(updatedNotification);
            return Optional.of(updatedNotification); // Return the updated notification
        } else {
            return Optional.empty(); // Return empty if not found
        }
    }

    // Get all notifications
    public List<NotificationEntity> getAllNotifications() {
        return notificationRepository.findAll();
    }

    // Get a notification by ID
    public Optional<NotificationEntity> getNotificationById(Long notifiID) {
        return notificationRepository.findById(notifiID);
    }

    // Delete a notification by ID
    public void deleteNotification(Long notifiID) {
        notificationRepository.deleteById(notifiID);
    }
}
