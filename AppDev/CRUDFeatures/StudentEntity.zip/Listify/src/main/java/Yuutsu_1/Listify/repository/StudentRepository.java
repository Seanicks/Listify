package Yuutsu_1.Listify.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import Yuutsu_1.Listify.entity.StudentEntity;

@Repository
public interface StudentRepository extends JpaRepository<StudentEntity,Integer> {
	
	StudentEntity findByLastName(String lastName);

}
