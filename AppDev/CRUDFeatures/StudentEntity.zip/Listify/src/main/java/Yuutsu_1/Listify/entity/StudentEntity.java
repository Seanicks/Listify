package Yuutsu_1.Listify.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class StudentEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Studentid;
	
	private String firstName;
    private String lastName;
    
    
    public StudentEntity() {
        super();
    }
    
    public StudentEntity(int Studentid, String firstName, String lastName) {
        super();
        this.Studentid = Studentid;
        this.firstName = firstName;
        this.lastName = lastName;
        
    }
    public int getId() {
        return Studentid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
