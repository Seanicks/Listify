package Yuutsu_1.Listify.service;

import java.util.List;
import java.util.NoSuchElementException;

import javax.naming.NameNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Yuutsu_1.Listify.entity.StudentEntity;
import Yuutsu_1.Listify.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	 public StudentEntity postStudentRecord(StudentEntity studentEntity) {
	        return studentRepository.save(studentEntity);
	    }
	 
	// Read - GET
	    public List<StudentEntity> getAllStudent() {
	        return studentRepository.findAll();
	    }
	    
	    @SuppressWarnings("finally")
	    public StudentEntity putStudentDetails(int id, StudentEntity newStudentDetails) {
	    	StudentEntity student=new StudentEntity();
	    	
	    	try {
	    		student = studentRepository.findById(id).get();
	    		
	    		student.setFirstName(newStudentDetails.getFirstName());
	    		student.setLastName(newStudentDetails.getLastName());
	    		
	    	}catch(NoSuchElementException nex) {
	    		throw new NameNotFoundException("StudentEntity "+id+"not found");
	    	}finally {
	    		return studentRepository.save(student);
	    	}
	    }
	    
	    public String deleteStudent(int id) {
	        String msg = "";
	        if(studentRepository.existsById(id)) {  
	        	studentRepository.deleteById(id);    
	            msg = "Student record successfully deleted";
	        } else {
	            msg = "Student with ID " + id + " not found!";
	        }
	        return msg;
	    }

}
