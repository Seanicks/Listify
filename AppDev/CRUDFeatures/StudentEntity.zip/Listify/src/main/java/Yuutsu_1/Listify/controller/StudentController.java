package Yuutsu_1.Listify.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import Yuutsu_1.Listify.entity.StudentEntity;
import Yuutsu_1.Listify.service.StudentService;

@RestController
@RequestMapping("/api/student")
@CrossOrigin

public class StudentController {
	
	@Autowired
	private StudentService studentservice;
	
	@GetMapping("/print")
    public String print() {
        return "Hello, Seanjames Lacaba";
    }
	
	// Create - POST
    @PostMapping("/postStudentRecord")
    public StudentEntity postStudentRecord(@RequestBody StudentEntity studentEntity) {
        return studentservice.postStudentRecord(studentEntity);
    }
    
 // Read - GET
    @GetMapping("/getAllStudent")
    public List<StudentEntity> getAllStudent(){
        return studentservice.getAllStudent();
    }
// update of crud
    
    @PutMapping("/putStudentDetails")
    public StudentEntity putStudentDetails(@RequestParam int id, @RequestBody StudentEntity newstudentDetails) {
    	return studentservice.putStudentDetails(id, newstudentDetails);
    }
    @DeleteMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable int id) {
    	return studentservice.deleteStudent(id);
    }
	

}
