package Yuutsu_1.Listify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
