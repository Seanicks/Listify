package Yuutsu_1.Listify.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class SubnoteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subnoteID;

    private String subnote;
    
    public Long getSubnoteID() {
        return subnoteID;
    }

    public void setSubnoteID(Long subnoteID) {
        this.subnoteID = subnoteID;
    }

    public String getSubnote() {
        return subnote;
    }

    public void setSubnote(String subnote) {
        this.subnote = subnote;
    }

}

