package Yuutsu_1.Listify.Repository;

import Yuutsu_1.Listify.Entity.SubnoteEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubnoteRepository extends JpaRepository<SubnoteEntity, Long> {


}