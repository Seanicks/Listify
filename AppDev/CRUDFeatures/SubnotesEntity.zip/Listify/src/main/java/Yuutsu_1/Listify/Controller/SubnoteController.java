package Yuutsu_1.Listify.Controller;

import Yuutsu_1.Listify.Entity.SubnoteEntity;
import Yuutsu_1.Listify.Service.SubnoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/subnotes")
public class SubnoteController {

    @Autowired
    private SubnoteService subnotesService;

    @GetMapping
    public List<SubnoteEntity> getAllSubnotes() {
        return subnotesService.getAllSubnotes();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SubnoteEntity> getSubnoteById(@PathVariable Long id) {
        return subnotesService.getSubnoteById(id)
                .map(subnote -> ResponseEntity.ok().body(subnote))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public SubnoteEntity createSubnote(@RequestBody SubnoteEntity subnote) {
        return subnotesService.createSubnote(subnote);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SubnoteEntity> updateSubnote(@PathVariable Long id, @RequestBody SubnoteEntity subnoteDetails) {
        return ResponseEntity.ok(subnotesService.updateSubnote(id, subnoteDetails));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSubnote(@PathVariable Long id) {
        subnotesService.deleteSubnote(id);
        return ResponseEntity.noContent().build();
    }
}