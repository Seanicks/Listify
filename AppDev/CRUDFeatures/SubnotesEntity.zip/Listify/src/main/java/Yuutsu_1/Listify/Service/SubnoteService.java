package Yuutsu_1.Listify.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Yuutsu_1.Listify.Entity.SubnoteEntity;
import Yuutsu_1.Listify.Repository.SubnoteRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SubnoteService {

    @Autowired
    private SubnoteRepository subnotesRepository;

    public List<SubnoteEntity> getAllSubnotes() {
        return subnotesRepository.findAll();
    }

    public Optional<SubnoteEntity> getSubnoteById(Long subnoteID) {
        return subnotesRepository.findById(subnoteID);
    }

    public SubnoteEntity createSubnote(SubnoteEntity subnote) {
        return subnotesRepository.save(subnote);
    }

    public SubnoteEntity updateSubnote(Long subnoteID, SubnoteEntity subnoteDetails) {
        SubnoteEntity subnote = subnotesRepository.findById(subnoteID).orElseThrow();
        subnote.setSubnote(subnoteDetails.getSubnote());
        return subnotesRepository.save(subnote);
    }

    public void deleteSubnote(Long subnoteID) {
        subnotesRepository.deleteById(subnoteID);
    }
}
