package Yuutsu_1.Listify.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import Yuutsu_1.Listify.Entity.TaskEntity;

public interface TaskRepository extends JpaRepository<TaskEntity, Integer>{
	public TaskEntity findByTask(String task);

}
