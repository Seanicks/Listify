package Yuutsu_1.Listify.Contrtoller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import Yuutsu_1.Listify.Entity.TaskEntity;
import Yuutsu_1.Listify.Service.TaskService;

@RestController
@RequestMapping("/api/task")
public class TaskController {

    @Autowired
    TaskService tserv;

    // Create
    @PostMapping("/posttask")
    public TaskEntity postTask(@RequestBody TaskEntity task) {
        return tserv.postTask(task);
    }

    // Read
    @GetMapping("/getAllTasks")
    public List<TaskEntity> getAllTasks() {
        return tserv.getAllTasks();
    }

    // Update
    @PutMapping("/putTaskDetails/{id}") // Changed to PathVariable
    public TaskEntity putTaskDetails(@PathVariable int id, @RequestBody TaskEntity newTaskDetails) {
        return tserv.putTaskDetails(id, newTaskDetails);
    }

    // Delete
    @DeleteMapping("/deleteTask/{id}")
    public String deleteTask(@PathVariable int id) {
        return tserv.deleteTask(id);
    }
}
