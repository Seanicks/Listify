package Yuutsu_1.Listify.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Yuutsu_1.Listify.Entity.TaskEntity;
import Yuutsu_1.Listify.Repository.TaskRepository;

@Service
public class TaskService {

    @Autowired
    TaskRepository trepo;

    public TaskService() {
        super();
    }

    // Create
    public TaskEntity postTask(TaskEntity task) {
        return trepo.save(task);
    }

    // Read
    public List<TaskEntity> getAllTasks() {
        return trepo.findAll();
    }

    // Update
    public TaskEntity putTaskDetails(int id, TaskEntity newTaskDetails) {
        Optional<TaskEntity> optionalTask = trepo.findById(id);
        
        if (optionalTask.isPresent()) {
            TaskEntity task = optionalTask.get();
            task.setTask(newTaskDetails.getTask());
            task.setTaskStatus(newTaskDetails.getTaskStatus());
            return trepo.save(task);
        } else {
            throw new NoSuchElementException("Task " + id + " not found."); // or throw a custom exception
        }
    }

    // Delete
    public String deleteTask(int id) {
        Optional<TaskEntity> optionalTask = trepo.findById(id);
        
        if (optionalTask.isPresent()) {
            trepo.delete(optionalTask.get());
            return "Task with ID " + id + " has been deleted.";
        } else {
            return "Task with ID " + id + " not found.";
        }
    }
}
